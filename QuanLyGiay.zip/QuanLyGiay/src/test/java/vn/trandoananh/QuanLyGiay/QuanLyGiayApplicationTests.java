package vn.trandoananh.QuanLyGiay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuanLyGiayApplicationTests {

	@Test
	void contextLoads() {
	}

}
